# Projeto Lógico - Relatório

<!-- chaves após imagens são sintaxe para o pandoc -->

- Universidade Federal de Sergipe - CCET - Departamento de Computação
- COMP0455 - BANCO DE DADOS I (2023.1 - T01)
- Prof. Dr. André Britto de Carvalho
- Pedro Vinícius de Araújo Barreto
- João Filipe de Araújo Santos Rezende

Todas as imagens usadas estão no zip.

## DER

![](./lojinha_der.png){width=600 height=600}

Algumas mudanças foram feitas: 

- Remoção de entidades que podem ser transformadas em enumerações simples
- Criação de uma entidade para classe de campeões
- Entidade Item passa a concentrar mais atributos, em particular o derivado
  `preco_final ()` e a data de lançamento

## Esquema relacional

![](./lojinha_schema.png){width=600 height=600}

Todos os mapeamentos foram feitos seguindo as regras genéricas dos livros da
disciplina. A única exceção é que como algumas das especializações da entidade
Item acabaram sem nenhum atributo específico para elas, adotamos uma abordagem
híbrida para mapear a especialização: Especializações com atributos específicos
viraram tabelas, enquanto as sem atributos únicos só existem na tabela Item,
onde sua especialização é indicada com a coluna `tipo` que é um tipo enumerado.

## RDS

Uma instância RDS foi criada usando Postgres como a engine. O script utilizado
para executar as ações de DDL foi o `lojinha_schema.sql`. Foi criado um usuário
`professor` cuja senha é `professor` no banco. Ele tem acesso total ao schema
`lojinha`.

O endpoint da instância é
[http://lojinha-db.c9c5bcf9eeyi.us-east-1.rds.amazonaws.com/](http://lojinha-db.c9c5bcf9eeyi.us-east-1.rds.amazonaws.com/), com a porta 5432.

